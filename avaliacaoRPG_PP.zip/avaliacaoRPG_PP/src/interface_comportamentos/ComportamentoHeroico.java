package interface_comportamentos;

public interface ComportamentoHeroico 
{
	public abstract void atacar();
	public abstract void defender();
	public abstract void saltar();
}
