//Questão 1. a)
package interface_comportamentos;

public interface ComportamentoNormal 
{
	public abstract void andar();
	public abstract void guardarItem();
	public abstract void usarItem();
}
