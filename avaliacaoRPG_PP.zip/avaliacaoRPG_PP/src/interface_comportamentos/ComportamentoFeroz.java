package interface_comportamentos;

public interface ComportamentoFeroz 
{
	public abstract void atirarFogo();
	public abstract void voar();
	public abstract void morder();
}
