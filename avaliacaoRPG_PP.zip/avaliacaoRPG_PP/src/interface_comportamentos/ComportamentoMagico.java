package interface_comportamentos;

public interface ComportamentoMagico 
{
	public abstract void invisibilidade();
	public abstract void ultraRapidez();
}
